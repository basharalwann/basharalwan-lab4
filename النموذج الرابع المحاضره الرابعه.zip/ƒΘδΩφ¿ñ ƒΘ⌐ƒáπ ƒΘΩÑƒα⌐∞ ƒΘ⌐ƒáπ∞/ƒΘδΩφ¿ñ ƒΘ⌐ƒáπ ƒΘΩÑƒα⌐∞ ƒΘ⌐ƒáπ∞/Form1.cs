﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace النموذج_الرابع_المحاضره_الرابعه
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button9.Location = new Point(button9.Left, button9.Top - 5);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button9.Size = new Size(button9.Width, button9.Height + 5);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button9.Size = new Size(button9.Width, button9.Height - 5);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button9.Location = new Point(button9.Left, button9.Top + 5);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button9.Left -= 5;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button9.Width -= 5;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button9.Width += 5;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button9.Left += 5;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                for (int i = 0; i < Top; i++)
                {
                    // MessageBox.Show("Test"); 
                    if (checkBox5.Checked) button9.Top -= Convert.ToInt16(checkBox5.Text);
                    else if (checkBox10.Checked) button9.Top -= Convert.ToInt32(checkBox10.Text);
                    else if (checkBox15.Checked) button9.Top -= Convert.ToInt32(checkBox15.Text);
                    else if (checkBox20.Checked) button9.Top -= Convert.ToInt32(checkBox20.Text);
                    for (int j = 0; j < 100000000; j++) ;
                }
            else if (radioButton2.Checked)
                for (int i = 0; i < Top; i++)
                {
                    if (checkBox5.Checked) button9.Top += Convert.ToInt32(checkBox5.Text);
                    else if (checkBox10.Checked) button9.Top += Convert.ToInt32(checkBox10.Text);
                    else if (checkBox15.Checked) button9.Top += Convert.ToInt32(checkBox15.Text);
                    else if (checkBox20.Checked) button9.Top += Convert.ToInt32(checkBox20.Text);
                    for (int j = 0; j < 10000000; j++) ;

                }
        }
    }
}
